# 12864-WH-33V


![12864-WH-33V-005-500x500](https://user-images.githubusercontent.com/4562957/141742336-52ab2d08-6bf8-490f-9fe6-eb69a9b734de.jpg)

This is a framed type LCD graphical 128x64 with LED backlight.
